grammar AWO;

programa: sentencia* EOF;

sentencia
    : IDENTIFICADOR '=' expresion SALTO
    ;

expresion
    : expresion op=('*'|'/') expresion
    | expresion op=('+'|'-') expresion
    | NUMERO
    | IDENTIFICADOR
    | '(' expresion ')'
    ;

IDENTIFICADOR : [a-zA-Z_][a-zA-Z_0-9]* ;

NUMERO : [0-9]+ ;

SALTO : '\r'? '\n' ;

ESPACIOS : [ \t]+ -> skip ;
