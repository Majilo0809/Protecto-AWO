from antlr4 import *

from generado.AWOLexer import AWOLexer
from generado.AWOParser import AWOParser

from interprete import InterpreteAWO
from memoria import Memoria


def ejecutar(archivo):

    entrada = FileStream(archivo, encoding="utf-8")

    lexer = AWOLexer(entrada)

    tokens = CommonTokenStream(lexer)

    parser = AWOParser(tokens)

    arbol = parser.programa()

    memoria = Memoria()

    interprete = InterpreteAWO(memoria)

    interprete.visit(arbol)


if __name__ == "__main__":
	archivo  = input("Ingrese el nombre del archivo a ejecutar: ")
	ejecutar(archivo)

