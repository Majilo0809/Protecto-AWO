from generado.AWOVisitor import AWOVisitor


class InterpreteAWO(AWOVisitor):

    def __init__(self, memoria):
        self.memoria = memoria


    def visitSentencia(self, ctx):

        nombre = ctx.IDENTIFICADOR().getText()

        valor = self.visit(ctx.expresion())

        self.memoria.asignar(nombre, valor)

        print(nombre, "=", valor)


    def visitExpresion(self, ctx):

        if ctx.NUMERO():
            return int(ctx.NUMERO().getText())

        if ctx.IDENTIFICADOR():
            return self.memoria.obtener(ctx.IDENTIFICADOR().getText())

        if ctx.getChildCount() == 3:

            izquierda = self.visit(ctx.expresion(0))
            derecha = self.visit(ctx.expresion(1))

            operador = ctx.op.text

            if operador == "+":
                return izquierda + derecha

            if operador == "-":
                return izquierda - derecha

            if operador == "*":
                return izquierda * derecha

            if operador == "/":
                return izquierda / derecha

        return self.visit(ctx.expresion(0))
