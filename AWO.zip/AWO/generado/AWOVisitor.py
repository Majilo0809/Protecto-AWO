# Generated from AWO.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .AWOParser import AWOParser
else:
    from AWOParser import AWOParser

# This class defines a complete generic visitor for a parse tree produced by AWOParser.

class AWOVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by AWOParser#programa.
    def visitPrograma(self, ctx:AWOParser.ProgramaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by AWOParser#sentencia.
    def visitSentencia(self, ctx:AWOParser.SentenciaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by AWOParser#expresion.
    def visitExpresion(self, ctx:AWOParser.ExpresionContext):
        return self.visitChildren(ctx)



del AWOParser