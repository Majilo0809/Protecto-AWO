# Generated from AWO.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .AWOParser import AWOParser
else:
    from AWOParser import AWOParser

# This class defines a complete listener for a parse tree produced by AWOParser.
class AWOListener(ParseTreeListener):

    # Enter a parse tree produced by AWOParser#programa.
    def enterPrograma(self, ctx:AWOParser.ProgramaContext):
        pass

    # Exit a parse tree produced by AWOParser#programa.
    def exitPrograma(self, ctx:AWOParser.ProgramaContext):
        pass


    # Enter a parse tree produced by AWOParser#sentencia.
    def enterSentencia(self, ctx:AWOParser.SentenciaContext):
        pass

    # Exit a parse tree produced by AWOParser#sentencia.
    def exitSentencia(self, ctx:AWOParser.SentenciaContext):
        pass


    # Enter a parse tree produced by AWOParser#expresion.
    def enterExpresion(self, ctx:AWOParser.ExpresionContext):
        pass

    # Exit a parse tree produced by AWOParser#expresion.
    def exitExpresion(self, ctx:AWOParser.ExpresionContext):
        pass



del AWOParser