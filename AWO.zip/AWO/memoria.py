class Memoria:

    def __init__(self):
        self.variables = {}

    def asignar(self, nombre, valor):
        self.variables[nombre] = valor

    def obtener(self, nombre):

        if nombre in self.variables:
            return self.variables[nombre]

        raise Exception(f"Variable '{nombre}' no definida")
